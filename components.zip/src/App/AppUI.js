import React from 'react';
import { TodoCounter } from '../TodoCounter';
import { TodoSearch } from '../TodoSearch/TodoSearch';
import { TodoList } from '../TodoList';
import { TodoItem } from '../TodoItem';
import { CreateTodoButton } from '../CreateTodoButton/';
import { CreateTask } from '../CreateTask';
import { useTheme  } from '@mui/material/styles';
import { Box,useMediaQuery } from '@mui/material';

function AppUI ({
    loading,
    error,
    completedTodos,
    totalTodos,
    searchValue,
    setSearchValue,
    filteredTodos,
    eliminaTodo,
    toggleTodoCompletion
}) {
    const theme = useTheme();
    const isMdDown = useMediaQuery(theme.breakpoints.down('md')); // `true` for `md` and smaller screens
    return (
        <Box className='mainContainer'>
          <Box className='newTaskContainer'>
            <CreateTask/>
          </Box>
          <Box className='task-list'>
            <TodoCounter completed={completedTodos} total={totalTodos}/>
            <TodoSearch
              searchValue={searchValue}  //Heredando propiedades
              setSearchValue={setSearchValue}
            />
            <TodoList>
              {loading && <Box>Cargando...</Box>}
              {error && <Box>Error al cargar</Box>}
              {(!loading && filteredTodos.length == 0) && <Box>No hay todo's por hacer</Box>}
              {filteredTodos.map(todo => (
                <TodoItem 
                  key={todo.id}
                  id={todo.id} 
                  text={todo.text}
                  completed={todo.completed}
                  eliminaTodo={eliminaTodo}
                  //toggleTodoCompletion={toggleTodoCompletion}
                  toggleTodoCompletion={() => toggleTodoCompletion(todo.id)}
                />
              ))}
            </TodoList>
            {isMdDown && <CreateTodoButton />}
          </Box>      
        </Box>
    );
}
export {AppUI};